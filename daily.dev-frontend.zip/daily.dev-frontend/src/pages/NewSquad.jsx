import React from "react";
import Layout from "../components/Layout/Layout";


const NewSquad = () => {
  return (
  <Layout>
      <div>Newsquard</div>
      
  </Layout>
  );
};

export default NewSquad;
