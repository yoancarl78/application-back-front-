import React from "react";
import Layout from "../../../components/Layout/Layout";

const Explore = () => {
  return <Layout></Layout>;
};

export default Explore;
