import React from "react";
import Layout from "../../../components/Layout/Layout";

const ByDate = () => {
  return <Layout></Layout>;
};

export default ByDate;
