import React from "react";
import Layout from "../../components/Layout/Layout";

const LeaderBoard = () => {
  return <Layout></Layout>;
};

export default LeaderBoard;
