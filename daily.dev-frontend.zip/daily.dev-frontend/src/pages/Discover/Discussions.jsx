import React from "react";
import Layout from "../../components/Layout/Layout";

const Discussions = () => {
 
 
  return (
  <Layout>

      </Layout>
  );
};

export default Discussions;



