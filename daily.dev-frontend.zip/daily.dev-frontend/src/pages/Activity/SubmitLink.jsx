import React from "react";
import Layout from "../../components/Layout/Layout";

const SubmitLink = () => {
  return <Layout></Layout>;
};

export default SubmitLink;
