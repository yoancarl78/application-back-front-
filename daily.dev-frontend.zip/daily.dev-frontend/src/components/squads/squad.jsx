import React, { useEffect } from "react";

const squad = ({ name, picture, squadTypeId }) => {
  useEffect(() => {
    const handleType = () => {
      try {
      } catch {}
    };
  });
  return <div></div>;
};

export default squad;
